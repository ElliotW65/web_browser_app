using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using F21SC_CW1_WebBrowser.Model;
using F21SC_CW1_WebBrowser.Controller;
using F21SC_CW1_WebBrowser.Collections;
using System.Net.Http;

namespace F21SC_CW1_WebBrowser
{
    static class Program
    {

        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {

            string path = "";

            BrowserModel model = new BrowserModel(path);

            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            View GUI = new View();
            BrowserController controller = new BrowserController(model, GUI);

            Application.Run(GUI);

        }
    }
}
