﻿using System;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Collections.Generic;
using F21SC_CW1_WebBrowser.Collections;
using F21SC_CW1_WebBrowser.Interfaces;
using F21SC_CW1_WebBrowser.AbstractClasses;
using System.Text;
using System.Net.Http;

namespace F21SC_CW1_WebBrowser.Model
{
    public class BrowserModel : AbBrowser
    {
        /// <summary>
        /// The BrowserModel class provides a concrete implementation of
        /// AbBrowser to be instantiated when the application is run.
        /// </summary>

        public BrowserModel(string path) : base(path)
        {

        }


    }
}
