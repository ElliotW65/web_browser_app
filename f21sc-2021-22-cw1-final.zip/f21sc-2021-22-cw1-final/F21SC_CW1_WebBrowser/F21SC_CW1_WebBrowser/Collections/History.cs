﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace F21SC_CW1_WebBrowser.Collections
{
    public class History<TKey, TValue> : IEnumerable<KeyValuePair<TKey, TValue>>
    {
        /// <summary>
        /// The History class is designed to store the history of
        /// searches by the user on the GUI.
        /// </summary>

        // History is implemented using generics so the specific data types
        // can be specified in the concrete implementation.
        // Implements the IEnumerable interface which enables History
        // to be indexed and used in a foreach loop.

        private SortedList<TKey, TValue> _history;

        public History()
        {
            _history = new SortedList<TKey, TValue>();
        }

        public History<TKey, TValue> GetHistory()
        {
            return this;
        }

        public int GetLength()
        {
           return _history.Count;
        }

        public void Add(TKey item, TValue value)
        {
            if (!_history.ContainsKey(item))
            {
                _history.Add(item, value);
            }
            
        }

        public void Remove(TKey item)
        {
            _history.Remove(item);
        }

        public TValue this[int index]
        {
            get
            {
                try
                {
                    if(index >= 0 && index < _history.Count)
                    {
                        
                    }
                    return _history.Values[index];

                }
                catch (ArgumentOutOfRangeException i)
                {
                    throw new ArgumentOutOfRangeException();
                }

            }
            set
            {
                try
                {
                    _history.Values[index] = value;
                }
                catch (IndexOutOfRangeException i)
                {
                    Debug.WriteLine(i.StackTrace);
                }
            }
        }

        public TValue GetValue(TKey key)
        {
            TValue value;

            if (_history.TryGetValue(key, out value))
            {
                return value;
            }
            else
            {
                return default(TValue);
            }
        }

        public ICollection<TKey> GetKeys()
        {
            return _history.Keys;
        }

        public void DeleteHistory()
        {
            _history.Clear();
        }

        public IEnumerator<KeyValuePair<TKey, TValue>> GetEnumerator()
        {
            foreach(KeyValuePair<TKey, TValue> item in _history)
            {
                yield return item;
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
            throw new NotImplementedException();
        }
    }
}
