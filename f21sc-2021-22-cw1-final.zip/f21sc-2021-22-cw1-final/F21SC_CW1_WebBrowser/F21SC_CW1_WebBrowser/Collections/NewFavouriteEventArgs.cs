﻿using System;
using System.Collections.Generic;
using System.Text;

namespace F21SC_CW1_WebBrowser.Collections
{
    public class NewFavouriteEventArgs : EventArgs
    {
        /// <summary>
        /// The NewFavouriteEventArgs class is designed to store the names
        /// (new and old) and url of a new favrouie added by thr user.
        /// </summary>

        private string _name;
        private string _oldName;
        private string _url;

        public NewFavouriteEventArgs()
        {

        }

        public string NewName
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

        public string OldName
        {
            get
            {
                return _oldName;
            }
            set
            {
                _oldName = value;
            }
        }

        public string NewLink
        {
            get
            {
                return _url;
            }
            set
            {
                _url = value;
            }
        }

    }
}
