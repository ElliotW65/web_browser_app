﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace F21SC_CW1_WebBrowser.Collections
{
    public class BulkDownloadEventArgs<T> : EventArgs, IEnumerable<T>
    {
        /// <summary>
        /// The BulkDownloadEventArgs class is designed to store the result 
        /// of a bulk download request.
        /// </summary>
 
        // In this particular implementation the class stored a list of
        // BulkDownldObj objects, each one corresponding to a request
        // in the bulk download file.

        private List<T> _results;

        public BulkDownloadEventArgs()
        {
            _results = new List<T>();
        }

        public void Add(T item)
        {
            _results.Add(item);
        }

        public void Clear()
        {
            _results.Clear();
        }

        public IEnumerator<T> GetEnumerator()
        {
            foreach (T item in _results)
            {
                yield return item;
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
            throw new NotImplementedException();
        }
    }
}
