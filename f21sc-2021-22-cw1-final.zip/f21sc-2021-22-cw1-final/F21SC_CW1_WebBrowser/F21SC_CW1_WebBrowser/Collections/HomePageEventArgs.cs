﻿using System;
using System.Collections.Generic;
using System.Text;

namespace F21SC_CW1_WebBrowser.Collections
{
    public class HomePageEventArgs : EventArgs
    {
        /// <summary>
        /// The HomePageEventArgs class is designed to store the URL
        /// of the new home page set by the user.
        /// </summary>

        private string _url;

        public HomePageEventArgs()
        {

        }

        public string URL
        {
            get
            {
                return _url;
            }
            set
            {
                _url = value;
            }
        }

    }
}
