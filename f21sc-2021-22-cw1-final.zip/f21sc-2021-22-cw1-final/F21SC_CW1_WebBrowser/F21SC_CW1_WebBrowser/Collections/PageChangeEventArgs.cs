﻿using System;
using System.Collections.Generic;
using System.Text;

namespace F21SC_CW1_WebBrowser.Collections
{
    public class PageChangeEventArgs : EventArgs
    {
        /// <summary>
        /// The PageChangeEventArgs class is designed to store the result
        /// of an HTTP request in preparation for it to be shown in the
        /// browser.
        /// </summary>

        private int _requestStatus;
        private string _url;
        private string _statusCode;
        private string _status;
        private string _title;
        private string _html;

        public PageChangeEventArgs()
        {

        }

        public int RequestStatus
        {
            get
            {
                return _requestStatus;
            }
            set
            {
                _requestStatus = value;
            }
        }

        public string URL
        {
            get
            {
                return _url;
            }
            set
            {
                _url = value;
            }
        }

        public string StatusCode
        {
            get
            {
                return _statusCode;
            }
            set
            {
                _statusCode = value;
            }
        }

        public string Status
        {
            get
            {
                return _status;
            }
            set
            {
                _status = value;
            }
        }

        public string Title
        {
            get
            {
                return _title;
            }
            set
            {
                _title = value;
            }
        }

        public string HTML
        {
            get
            {
                return _html;
            }
            set
            {
                _html = value;
            }
        }

    }
}
