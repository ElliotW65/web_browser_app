﻿using System;
using System.Collections.Generic;
using System.Text;

namespace F21SC_CW1_WebBrowser.Collections
{
    public class RequestEventArgs :  EventArgs
    {

        /// <summary>
        /// The RequestEventArgs class is designed to store the url
        /// of a new HTTP request that is waiting to be sent.
        /// </summary>

        private string _url;


        public RequestEventArgs()
        {

        }

        public string Link
        {
            get
            {
                return _url;
            }
            set
            {
                _url = value;
            }
        }

    }
}
