﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace F21SC_CW1_WebBrowser.Collections
{
    public class Favourites : IEnumerable<Favourites>
    {
        /// <summary>
        /// The Favourites class is designed to store favrouites added
        /// by the user in the GUI.
        /// </summary>
         
        // Implements the IEnumerable interface which enables Favourites
        // to be indexed and used in a foreach loop.

        private IDictionary<string, string> _favourites;

        public Favourites()
        {
            _favourites = new Dictionary<string, string>();
        }

        public Favourites GetFavourites()
        {
            return this;
        }

        public void Add(string key, string value)
        {
            try
            {
                _favourites.Add(key, value);
            }
            catch (ArgumentException)
            {
                throw new ArgumentException();
            }
        }

        public ICollection<string> GetKeys()
        {
            return _favourites.Keys;
        }

        public string GetValue(string key)
        {
            string value = "";
            if (_favourites.TryGetValue(key, out value))
            {
                return value;
            }
            else
            {
                return null;
            }
            
        }

        public void RemoveValue(string key)
        {
            _favourites.Remove(key);
        }

        public void UpdateValue(string key, string newValue)
        {
            this.RemoveValue(key);

            this.Add(key, newValue);
        }

        public void UpdateKey(string newKey, string oldKey)
        {

            string value = this.GetValue(oldKey);

            this.RemoveValue(oldKey);

            this.Add(newKey, value);
        }

        public void ClearFavourites()
        {
            _favourites.Clear();
        }

        public IEnumerator<KeyValuePair<string, string>> GetEnumerator()
        {
            foreach (KeyValuePair<string, string> item in _favourites)
            {
                yield return item;
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
            throw new NotImplementedException();
        }

        IEnumerator<Favourites> IEnumerable<Favourites>.GetEnumerator()
        {
            throw new NotImplementedException();
        }
    }
}
