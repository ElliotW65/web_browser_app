﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace F21SC_CW1_WebBrowser.Collections
{
    public class BulkDownldObj
    {
        /// <summary>
        /// The BulkDownldObj class is designed to store the result of a
        /// URL search as part of a bulk download request.
        /// </summary>

        private int _statusCode;
        private long? _bytes;
        private string _url;

        public BulkDownldObj(int statusCode, long? bytes, string url)
        {
            _statusCode = statusCode;
            _bytes = bytes;
            _url = url;
        }

        public int StatusCode
        {
            get
            {
                return _statusCode;
            }
            set
            {
                _statusCode = value;
            }
        }

        public long? Bytes
        {
            get
            {
                return _bytes;
            }
            set
            {
                _bytes = value;
            }
        }
        public string URL
        {
            get
            {
                return _url;
            }
            set
            {
                _url = value;
            }
        }

        // Use reflection to serialise the properties of the object
        // allowing them to be printed to the GUI.
        public string Serialise()
        {
            string output = "";
            Type type = this.GetType();
            PropertyInfo[] properties = type.GetProperties();

            foreach(PropertyInfo p in properties)
            {
                output += String.Format("<{0}> ", p.GetValue(this, null));
            }

            return output;
        }

    }
}
