﻿
namespace F21SC_CW1_WebBrowser
{
    partial class View
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(View));
            this.searchBar = new System.Windows.Forms.TextBox();
            this.submitSearch = new System.Windows.Forms.Button();
            this.outputHTML = new System.Windows.Forms.TextBox();
            this.statusLabel = new System.Windows.Forms.Label();
            this.statusCodeOutput = new System.Windows.Forms.TextBox();
            this.showFavourites = new System.Windows.Forms.Button();
            this.addToFavourites = new System.Windows.Forms.Button();
            this.showHistory = new System.Windows.Forms.Button();
            this.backBtn = new System.Windows.Forms.Button();
            this.fwdBtb = new System.Windows.Forms.Button();
            this.bulkDownld = new System.Windows.Forms.Button();
            this.makeHomePage = new System.Windows.Forms.Button();
            this.pageTitle = new System.Windows.Forms.Label();
            this.refresh = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // searchBar
            // 
            this.searchBar.Location = new System.Drawing.Point(12, 7);
            this.searchBar.Name = "searchBar";
            this.searchBar.Size = new System.Drawing.Size(494, 27);
            this.searchBar.TabIndex = 0;
            this.searchBar.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // submitSearch
            // 
            this.submitSearch.Location = new System.Drawing.Point(512, 7);
            this.submitSearch.Name = "submitSearch";
            this.submitSearch.Size = new System.Drawing.Size(94, 29);
            this.submitSearch.TabIndex = 2;
            this.submitSearch.Text = "Search";
            this.submitSearch.UseVisualStyleBackColor = true;
            this.submitSearch.Click += new System.EventHandler(this.submitSearch_Click);
            // 
            // outputHTML
            // 
            this.outputHTML.Location = new System.Drawing.Point(12, 119);
            this.outputHTML.Multiline = true;
            this.outputHTML.Name = "outputHTML";
            this.outputHTML.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.outputHTML.Size = new System.Drawing.Size(1367, 672);
            this.outputHTML.TabIndex = 3;
            this.outputHTML.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            // 
            // statusLabel
            // 
            this.statusLabel.AutoSize = true;
            this.statusLabel.Location = new System.Drawing.Point(130, 51);
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(91, 20);
            this.statusLabel.TabIndex = 4;
            this.statusLabel.Text = "Status Code:";
            this.statusLabel.Click += new System.EventHandler(this.label1_Click);
            // 
            // statusCodeOutput
            // 
            this.statusCodeOutput.Location = new System.Drawing.Point(227, 48);
            this.statusCodeOutput.Name = "statusCodeOutput";
            this.statusCodeOutput.Size = new System.Drawing.Size(175, 27);
            this.statusCodeOutput.TabIndex = 5;
            // 
            // showFavourites
            // 
            this.showFavourites.Location = new System.Drawing.Point(1051, 7);
            this.showFavourites.Name = "showFavourites";
            this.showFavourites.Size = new System.Drawing.Size(94, 29);
            this.showFavourites.TabIndex = 6;
            this.showFavourites.Text = "Favourites";
            this.showFavourites.UseVisualStyleBackColor = true;
            this.showFavourites.Click += new System.EventHandler(this.button2_Click);
            // 
            // addToFavourites
            // 
            this.addToFavourites.Location = new System.Drawing.Point(612, 7);
            this.addToFavourites.Name = "addToFavourites";
            this.addToFavourites.Size = new System.Drawing.Size(167, 29);
            this.addToFavourites.TabIndex = 7;
            this.addToFavourites.Text = "Add As Favourite";
            this.addToFavourites.UseVisualStyleBackColor = true;
            this.addToFavourites.Click += new System.EventHandler(this.addToFavourites_Click);
            // 
            // showHistory
            // 
            this.showHistory.Location = new System.Drawing.Point(1151, 7);
            this.showHistory.Name = "showHistory";
            this.showHistory.Size = new System.Drawing.Size(94, 29);
            this.showHistory.TabIndex = 8;
            this.showHistory.Text = "History";
            this.showHistory.UseVisualStyleBackColor = true;
            this.showHistory.Click += new System.EventHandler(this.showHistory_Click);
            // 
            // backBtn
            // 
            this.backBtn.Image = ((System.Drawing.Image)(resources.GetObject("backBtn.Image")));
            this.backBtn.Location = new System.Drawing.Point(12, 47);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(53, 29);
            this.backBtn.TabIndex = 9;
            this.backBtn.UseVisualStyleBackColor = true;
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // fwdBtb
            // 
            this.fwdBtb.Image = ((System.Drawing.Image)(resources.GetObject("fwdBtb.Image")));
            this.fwdBtb.Location = new System.Drawing.Point(71, 47);
            this.fwdBtb.Name = "fwdBtb";
            this.fwdBtb.Size = new System.Drawing.Size(53, 29);
            this.fwdBtb.TabIndex = 10;
            this.fwdBtb.UseVisualStyleBackColor = true;
            this.fwdBtb.Click += new System.EventHandler(this.fwdBtb_Click);
            // 
            // bulkDownld
            // 
            this.bulkDownld.Location = new System.Drawing.Point(1251, 7);
            this.bulkDownld.Name = "bulkDownld";
            this.bulkDownld.Size = new System.Drawing.Size(128, 29);
            this.bulkDownld.TabIndex = 11;
            this.bulkDownld.Text = "Bulk Download";
            this.bulkDownld.UseVisualStyleBackColor = true;
            this.bulkDownld.Click += new System.EventHandler(this.bulkDownld_Click);
            // 
            // makeHomePage
            // 
            this.makeHomePage.Location = new System.Drawing.Point(785, 7);
            this.makeHomePage.Name = "makeHomePage";
            this.makeHomePage.Size = new System.Drawing.Size(146, 29);
            this.makeHomePage.TabIndex = 12;
            this.makeHomePage.Text = "Set As Home Page";
            this.makeHomePage.UseVisualStyleBackColor = true;
            this.makeHomePage.Click += new System.EventHandler(this.makeHomePage_Click);
            // 
            // pageTitle
            // 
            this.pageTitle.AutoSize = true;
            this.pageTitle.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.pageTitle.Location = new System.Drawing.Point(12, 85);
            this.pageTitle.Name = "pageTitle";
            this.pageTitle.Size = new System.Drawing.Size(96, 28);
            this.pageTitle.TabIndex = 13;
            this.pageTitle.Text = "Page Title";
            // 
            // refresh
            // 
            this.refresh.Location = new System.Drawing.Point(409, 46);
            this.refresh.Name = "refresh";
            this.refresh.Size = new System.Drawing.Size(116, 29);
            this.refresh.TabIndex = 14;
            this.refresh.Text = "Refresh Page";
            this.refresh.UseVisualStyleBackColor = true;
            this.refresh.Click += new System.EventHandler(this.refresh_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1391, 803);
            this.Controls.Add(this.refresh);
            this.Controls.Add(this.pageTitle);
            this.Controls.Add(this.makeHomePage);
            this.Controls.Add(this.bulkDownld);
            this.Controls.Add(this.fwdBtb);
            this.Controls.Add(this.backBtn);
            this.Controls.Add(this.showHistory);
            this.Controls.Add(this.addToFavourites);
            this.Controls.Add(this.showFavourites);
            this.Controls.Add(this.statusCodeOutput);
            this.Controls.Add(this.statusLabel);
            this.Controls.Add(this.outputHTML);
            this.Controls.Add(this.submitSearch);
            this.Controls.Add(this.searchBar);
            this.Name = "Form1";
            this.Text = "Web Browser";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox searchBar;
        private System.Windows.Forms.Button submitSearch;
        private System.Windows.Forms.TextBox outputHTML;
        private System.Windows.Forms.Label statusLabel;
        private System.Windows.Forms.TextBox statusCodeOutput;
        private System.Windows.Forms.Button showFavourites;
        private System.Windows.Forms.Button addToFavourites;
        private System.Windows.Forms.Button showHistory;
        private System.Windows.Forms.Button backBtn;
        private System.Windows.Forms.Button fwdBtb;
        private System.Windows.Forms.Button bulkDownld;
        private System.Windows.Forms.Button makeHomePage;
        private System.Windows.Forms.Label pageTitle;
        private System.Windows.Forms.Button refresh;
    }
}

