﻿using System;
using System.Collections.Generic;
using System.Text;
using F21SC_CW1_WebBrowser.AbstractClasses;
using F21SC_CW1_WebBrowser.Interfaces;

namespace F21SC_CW1_WebBrowser.Controller
{
    public class BrowserController : AbController
    {
        /// <summary>
        /// The BrowserController class provides a concrete implementation of
        /// AbController to be instantiated when the application is run.
        /// </summary>

        public BrowserController(IBrowser browser, View view) : base(browser, view)
        {

        }
    }
}
