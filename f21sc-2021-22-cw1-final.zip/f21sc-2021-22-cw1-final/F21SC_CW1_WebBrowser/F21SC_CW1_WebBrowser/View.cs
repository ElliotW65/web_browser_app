﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using F21SC_CW1_WebBrowser.Collections;
using F21SC_CW1_WebBrowser.Model;
using F21SC_CW1_WebBrowser.AbstractClasses;
using F21SC_CW1_WebBrowser.Interfaces;

namespace F21SC_CW1_WebBrowser
{
    /// <summary>
    /// The View class provides an implementation of the web browser GUI.
    /// </summary>

    // To keep the application as loosely coupled as possible, the View class
    // publishes events when a user interacts with the GUI. Classes such as
    // a Controller class can subscribe to these events and perform actions
    // when they are triggered.
    // The View class implements as little logic as possible, but instead
    // exposes method that allow GUI elements to be updated based on logic/
    // processing done by other classes in response to View events.

    public partial class View : Form, IView
    {
        // Declare IView interface member events and delegates.

        public event IView.URLDelegate              RequestURLEvent;
        public event IView.GetFavouritesDelegate    GetFavouritesEvent;
        public event IView.NewFavouriteDelegate     NewFavouriteEvent;
        public event IView.NewHomePageDelegate      NewHomePageEvent;
        public event IView.PageTraversalDelegate    PageTraversalEvent;

        public event EventHandler<NewFavouriteEventArgs>    NewFaveNameEvent;
        public event EventHandler<string>                   RemoveFavouriteEvent;
        public event EventHandler<string>                   GetFavURLEvent;
        public event EventHandler<string>                   BulkdDownldEvent;
        public event EventHandler<string>                   DeleteHistoryItemEvent;
        public event EventHandler                           GetHistoryEvent;
        public event EventHandler                           DeleteAllHistoryEvent;
        public event EventHandler                           DeleteAllFavouritesEvent;
        public event EventHandler                           ViewCloseEvent;
        public event EventHandler                           ViewLoadedEvent;

        // Declare EventArgs variables that will act as shared objects
        // with the controller.

        private RequestEventArgs    _link;
        private HomePageEventArgs   _home;
        private NewFavouriteEventArgs _newFavouriteEvent;

        // Declare GUI elements for accepting user input.

        private static ListBox          _favouritesList;
        private static ListBox          _historyList;
        private Button                  _newFavourite;
        private Button                  _removeFavourite;
        private Button                  _removeAllFavourites;
        private Button                  _newFavouriteName;
        private Button                  _deleteHistoryItem;
        private Button                  _deleteHistory;
        private TextBox                 _name;
        private TextBox                 _newURL;
        private TextBox                 _newName;
        private TextBox                 _fileName;
        private Label                   _favouritesLabel;
        private Label                   _historyLabel;
        private int                     _pageIndex;
        private int                     _widthUpdate;
        

        // When the View constructor is called, the GUI is initialised
        // and a ListBox for favourites and a ListBox for history are
        // created.

        public View()
        {

            InitializeComponent();

            _link                       = new RequestEventArgs();
            _newFavouriteEvent          = new NewFavouriteEventArgs();
            _home                       = new HomePageEventArgs();
            _widthUpdate                = outputHTML.Width / 4;

            this.FormClosing            += new FormClosingEventHandler(this.View_FormClosing);

            _favouritesList             = new ListBox();
            _favouritesList.Name        = "favsListBox";
            _favouritesList.Size        = new Size(120, 95);
            _favouritesList.Visible     = false;
            

            _historyList                = new ListBox();
            _historyList.Name           = "historyListBox";
            _historyList.Size           = new Size(120, 95);
            _historyList.Visible        = false;

            // Add event so that user can click on history or
            // favourite item and be shown that web page.

            _favouritesList.MouseDoubleClick    += favesClick;
            _historyList.MouseDoubleClick       += historyClick;

 



        }

        // When the GUI has loaded, broascast an event.
        private void Form1_Load(object sender, EventArgs e)
        {
            ViewLoadedEvent?.Invoke(this, e);
        }

        // When the GUI is closed, broadcast an event.
        private void View_FormClosing(object sender, FormClosingEventArgs e)
        {
            ViewCloseEvent?.Invoke(this, EventArgs.Empty);
        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        // When the "Search" button is clicked, retrieve the URL from
        // the search bar, broadcast an event to search for the URL
        // and increment the pageIndex by 1.
        // If the search bar is blank, ask the user to enter a URL.
        private void submitSearch_Click(object sender, EventArgs e)
        {
            if(searchBar.Text != "")
            {
                _link.Link = Convert.ToString(searchBar.Text);
                RequestURLEvent(this, _link, "new");
                _pageIndex += 1;
            }
            else
            {
                ShowMessage("Please enter a URL.");
            }

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }


        // When the "Favourites" button is clicked, if the_favouritesList
        // or _historyList is currently visbile, remove them from the GUI.
        // If it is not visible, instantiate the labels and buttons and
        // add them to the GUI along with the _favouritesList.
        private void button2_Click(object sender, EventArgs e)
        {

            GetFavouritesEvent?.Invoke(this, EventArgs.Empty);

            if (_favouritesList.Visible)
            {
                _favouritesList.Visible = false;
                this.Controls.Remove(_favouritesList);
                this.Controls.Remove(_favouritesLabel);
                this.Controls.Remove(_newFavourite);
                this.Controls.Remove(_removeFavourite);
                this.Controls.Remove(_newFavouriteName);
                this.Controls.Remove(_removeAllFavourites);
                outputHTML.Width = outputHTML.Width + _widthUpdate;
            }
            else if (!_favouritesList.Visible)
            {
                if (_historyList.Visible)
                {
                    _historyList.Visible    = false;
                    this.Controls.Remove(_historyList);
                    this.Controls.Remove(_historyLabel);
                    this.Controls.Remove(_deleteHistoryItem);
                    this.Controls.Remove(_deleteHistory);
                    outputHTML.Width        = outputHTML.Width + _widthUpdate;
                }

                outputHTML.Width            = outputHTML.Width - _widthUpdate;
                int xPos                    = outputHTML.Location.X + outputHTML.Width + 10;
                int containerWidth          = this.Width - outputHTML.Width;
                _favouritesList.Location    = new Point(xPos, outputHTML.Location.Y);
                _favouritesList.Width       = containerWidth - 50;

                _favouritesLabel            = new Label();
                _favouritesLabel.Text       = "Favourites";
                _favouritesLabel.Font       = new Font("Segoe UI", 12);
                _favouritesLabel.Width      += 50;
                _favouritesLabel.Location   = new Point(xPos, outputHTML.Location.Y - (_favouritesLabel.Height + 10));

                _newFavourite               = new Button();
                _newFavourite.Text          = "Add Favourite";
                _newFavourite.Click         += NewFavourite;
                _newFavourite.Height        = submitSearch.Height;
                _newFavourite.Location      = new Point(xPos, outputHTML.Location.Y + (outputHTML.Height - _newFavourite.Height));

                _removeFavourite            = new Button();
                _removeFavourite.Text       = "Remove";
                _removeFavourite.Click      += RemoveFavourite;
                _removeFavourite.Height     = submitSearch.Height;
                _removeFavourite.Location   = new Point(_newFavourite.Location.X + (_newFavourite.Width + 10), _newFavourite.Location.Y);
                

                _newFavouriteName           = new Button();
                _newFavouriteName.Text      = "Update Name";
                _newFavouriteName.Height    = _newFavourite.Height;
                _newFavouriteName.Click     += NewFavouriteName;
                _newFavouriteName.Location  = new Point(_removeFavourite.Location.X + (_removeFavourite.Width + 10), _newFavourite.Location.Y);
                

                _removeAllFavourites        = new Button();
                _removeAllFavourites.Text   = "Delete All";
                _removeAllFavourites.Height = _newFavourite.Height;
                _removeAllFavourites.Click  += DeleteAllFavourites;
                _removeAllFavourites.Location = new Point(_newFavouriteName.Location.X + (_newFavouriteName.Width + 10), _newFavourite.Location.Y);

                _favouritesList.Height = outputHTML.Height - (_newFavourite.Height + 10);

                _favouritesList.Visible = true;

                this.Controls.Add(_favouritesList);
                this.Controls.Add(_favouritesLabel);
                this.Controls.Add(_newFavourite);
                this.Controls.Add(_removeFavourite);
                this.Controls.Add(_newFavouriteName);
                this.Controls.Add(_removeAllFavourites);
            }

        }

        // Iterate through all favourites and add the keys to
        // the _favouritesList if they are not already on there.
        public void UpdateFavouritesList(ICollection<string> keys)
        {
            foreach (string k in keys)
            {
                if (!_favouritesList.Items.Contains(k))
                {
                    _favouritesList.Items.Add(k);
                }
                
            }
        }


        // When a favourite is double clicked, broadcast an event
        // sending the favourite name as EventArgs.
        private void favesClick(object sender, MouseEventArgs e)
        {
            if (_favouritesList.SelectedItem != null)
            {
                GetFavURLEvent?.Invoke(this, _favouritesList.SelectedItem.ToString());

            }
        }

        // When a history item is double clicked, broadcast an event
        // sending the history DateTime stamp as EventArgs. 
        private void historyClick(object sender, MouseEventArgs e)
        {
            if (_historyList.SelectedItem != null)
            {
                string url = _historyList.SelectedItem.ToString();
                _link.Link = _historyList.SelectedItem.ToString().Substring(22, url.Length-23);
                
                RequestURLEvent?.Invoke(this, _link, "history");
                _pageIndex += 1;

            }
        }

        // Broadcast an event to delete all favourites.
        public void DeleteAllFavourites(object sender, EventArgs e)
        {
            DeleteAllFavouritesEvent?.Invoke(this, e);
            _favouritesList.Items.Clear();
        }

        // Create a temporary form to capture user input for
        // the name and URL of the new favourite.
        public void NewFavourite(object sender, EventArgs e)
        {

            Form addFave        = new Form();
            Label namelabel     = new Label();
            namelabel.Text      = "New Favourite Name";
            namelabel.Location  = new Point(0, 0);
            namelabel.Width     = 500;
            addFave.Controls.Add(namelabel);
            _name               = new TextBox();
            _name.Name          = "newFavouriteName";
            _name.Location      = new Point(0, 30);
            addFave.Controls.Add(_name);
            Label urlLabel      = new Label();
            urlLabel.Text       = "URL";
            urlLabel.Location   = new Point(0, 60);
            addFave.Controls.Add(urlLabel);
            _newURL             = new TextBox();
            _newURL.Name = "newURL";
            _newURL.Location    = new Point(0, 90);
            addFave.Controls.Add(_newURL);
            Button submit       = new Button();
            submit.Text         = "Submit";
            submit.Location     = new Point(0, 120);
            submit.Click        += AddFavourite;
            addFave.Controls.Add(submit);
            addFave.Show();

        }

        // Broadcast an event to add a new favourite using
        // the new name and URL captured by the temporary form.
        public void AddFavourite(object sender, EventArgs e)
        {
            if (_name.Text != "" && _newURL.Text != "")
            {
                _newFavouriteEvent.NewName = Convert.ToString(_name.Text);
                _newFavouriteEvent.NewLink = Convert.ToString(_newURL.Text);
                NewFavouriteEvent(this, _newFavouriteEvent);
                GetFavouritesEvent?.Invoke(this, EventArgs.Empty);
            }
            else
            {
                ShowMessage("Please enter a name and URL");
            }

        }

        // Create a temporary form to capture user input for
        // the new name of a selected favourite.
        public void NewFavouriteName(object sender, EventArgs e)
        {

            Form updateFaveName     = new Form();
            Label namelabel         = new Label();
            namelabel.Text          = "New Favourite Name";
            namelabel.Location      = new Point(0, 0);
            namelabel.Width         = 500;
            updateFaveName.Controls.Add(namelabel);
            _newName                = new TextBox();
            _newName.Location       = new Point(0, 30);
            updateFaveName.Controls.Add(_newName);
            Button submit           = new Button();
            submit.Text             = "Submit";
            submit.Location         = new Point(0, 120);
            submit.Click            += UpdateFavouriteName;
            updateFaveName.Controls.Add(submit);
            updateFaveName.Show();

        }

        // Broadcast an event to update a favourite name using
        // the new name captured by the temporary form.
        public void UpdateFavouriteName(object sender, EventArgs e)
        {
            if (_favouritesList.SelectedItem != null)
            {
                if (_newName.Text != "")
                {
                    _newFavouriteEvent.NewName = Convert.ToString(_newName.Text);
                    _newFavouriteEvent.OldName = _favouritesList.SelectedItem.ToString();
                    _favouritesList.Items.Remove(_favouritesList.SelectedItem);
                    NewFaveNameEvent?.Invoke(this, _newFavouriteEvent);
                    _favouritesList.Update();
                }
                else
                {
                    ShowMessage("Please enter a new favourite name.");
                }
            }
            else
            {
                ShowMessage("Please select an item to update.");
            }


        }

        // Broadcast an event to remove a favourite.
        public void RemoveFavourite(object sender, EventArgs e)
        {
            if(_favouritesList.SelectedItem != null)
            {
                string item = _favouritesList.SelectedItem.ToString();
                RemoveFavouriteEvent?.Invoke(this, item);
                _favouritesList.Items.Remove(_favouritesList.SelectedItem);
                _favouritesList.Update();
            }
            else
            {
                ShowMessage("Please select and item to remove.");
            }

        }

        // Create a temporary form to capture user input for
        // the new name of a favourite added through the search bar.
        private void addToFavourites_Click(object sender, EventArgs e)
        {
            Form updateFaveName = new Form();
            Label namelabel = new Label();
            namelabel.Text = "New Favourite Name";
            namelabel.Location = new Point(0, 0);
            namelabel.Width = 500;
            updateFaveName.Controls.Add(namelabel);
            _newName = new TextBox();
            _newName.Location = new Point(0, 30);
            updateFaveName.Controls.Add(_newName);
            Button submit = new Button();
            submit.Text = "Submit";
            submit.Location = new Point(0, 120);
            submit.Click += AddNewFavourite;
            updateFaveName.Controls.Add(submit);
            updateFaveName.Show();

        }

        // Broadcast an event to add a  new favourite using the
        // name entered by the user and the URL in the search bar.
        public void AddNewFavourite(object sender, EventArgs e)
        {
            Debug.WriteLine("Add fave triggered");
            if (_newName.Text != "" && searchBar.Text != "")
            {
                _newFavouriteEvent.NewName = Convert.ToString(_newName.Text);
                _newFavouriteEvent.NewLink = Convert.ToString(searchBar.Text);
                NewFavouriteEvent(this, _newFavouriteEvent);
                GetFavouritesEvent?.Invoke(this, EventArgs.Empty);
            }
            else
            {
                ShowMessage("Please enter a name and a URL.");
            }
            
        }

        // When the "History" button is clicked, if the_favouritesList
        // or _historyList is currently visbile, remove them from the GUI.
        // If it is not visible, instantiate the labels and buttons and
        // add them to the GUI along with the _historyList.
        private void showHistory_Click(object sender, EventArgs e)
        {
            {
                GetHistoryEvent?.Invoke(this, EventArgs.Empty);

                if (_historyList.Visible)
                {
                    _historyList.Visible = false;
                    this.Controls.Remove(_historyList);
                    this.Controls.Remove(_historyLabel);
                    this.Controls.Remove(_deleteHistoryItem);
                    this.Controls.Remove(_deleteHistory);
                    outputHTML.Width = outputHTML.Width + _widthUpdate;
                }
                else if (!_historyList.Visible)
                {
                    if (_favouritesList.Visible)
                    {
                        _favouritesList.Visible = false;
                        this.Controls.Remove(_favouritesList);
                        this.Controls.Remove(_favouritesLabel) ;
                        this.Controls.Remove(_newFavourite);
                        this.Controls.Remove(_removeFavourite);
                        this.Controls.Remove(_newFavouriteName);
                        this.Controls.Remove(_removeAllFavourites);
                        outputHTML.Width = outputHTML.Width + _widthUpdate;
                    }
                    outputHTML.Width = outputHTML.Width - _widthUpdate;
                    int xPos = outputHTML.Location.X + outputHTML.Width + 10;
                    int containerWidth = this.Width - outputHTML.Width;
                    _historyList.Location = new Point(xPos, outputHTML.Location.Y);
                    _historyList.Width = containerWidth - 50;
                    _historyList.HorizontalScrollbar = true;


                    _historyLabel = new Label();
                    _historyLabel.Text = "History";
                    _historyLabel.Font = new Font("Segoe UI", 12);
                    _historyLabel.Width += 50;
                    _historyLabel.Location = new Point(xPos, outputHTML.Location.Y - (_historyLabel.Height + 10));

                    _deleteHistoryItem = new Button();
                    _deleteHistoryItem.Text = "Delete";
                    _deleteHistoryItem.Click += DeleteHistoryItem;
                    _deleteHistoryItem.Height = submitSearch.Height;
                    _deleteHistoryItem.Location = new Point(xPos, outputHTML.Location.Y + (outputHTML.Height - _deleteHistoryItem.Height));


                    _deleteHistory = new Button();
                    _deleteHistory.Text = "Delete All";
                    _deleteHistory.Click += DeletHistory;
                    _deleteHistory.Height = submitSearch.Height;
                    _deleteHistory.Width = _deleteHistoryItem.Width * 2;
                    _deleteHistory.Location = new Point(_deleteHistoryItem.Location.X + (_deleteHistoryItem.Width + 10), outputHTML.Location.Y + (outputHTML.Height - _deleteHistory.Height));

                    _historyList.Height = outputHTML.Height - (_deleteHistoryItem.Height + 10);

                    _historyList.Visible = true;

                    this.Controls.Add(_historyList);
                    this.Controls.Add(_historyLabel);
                    this.Controls.Add(_deleteHistoryItem);
                    this.Controls.Add(_deleteHistory);
                }

            }
        }

        // Iterate through all hisory entries and add them to
        // the _historyList if they are not already on there. 
        public void LoadHistory(History<DateTime, string> history)
        {
            foreach (KeyValuePair<DateTime, string> pair in history)
            {
                if (!_historyList.Items.Contains(pair))
                {
                    _historyList.Items.Add(pair);
                }

            }
        }

        // Broadcast and event to delete the selected item from
        // the history.
        public void DeleteHistoryItem(object sender, EventArgs e)
        {
            DeleteHistoryItemEvent?.Invoke(this, _historyList.SelectedItem.ToString().Substring(1, 20));
            _historyList.Items.Remove(_historyList.SelectedItem);
        }

        // Broadcast and event to delete all history items.
        public void DeletHistory(object sender, EventArgs e)
        {
            DeleteAllHistoryEvent?.Invoke(this, e);
            _historyList.Items.Clear();
            InitPageIndex(0);
        }

        // Broadcast and event to move back a page in the history.
        private void backBtn_Click(object sender, EventArgs e)
        {
            PageTraversalEvent?.Invoke(this, _pageIndex, "back");
        }

        // Broadcast and event to move forward a page in the history.
        private void fwdBtb_Click(object sender, EventArgs e)
        {
            PageTraversalEvent?.Invoke(this, _pageIndex, "forward");
        }

        // Initialise the page index based on the length
        // of the history read in on start up.
        public void InitPageIndex(int historyLength)
        {
            _pageIndex = historyLength;
        }

        // Populate the search bar with the URL currently
        // being searched.
        public void UpdateSearchBar(string url)
        {
            searchBar.Text = url;
        }

        public void UpdateTitle(string title)
        {
            pageTitle.Text = title;
        }

        // Set the text of the main browser text box.
        public void UpdateBrowserWindow(string html)
        {
            outputHTML.Text = html;
        }

        public void UpdateStatusCode(string code)
        {
            statusCodeOutput.Text = code;
        }

        // Create a temporary form to capture user input for
        // the file name to bulk download.
        private void bulkDownld_Click(object sender, EventArgs e)
        {
            Form bulkDownlaodForm   = new Form();
            Label namelabel         = new Label();
            namelabel.Text          = "Bulk Download File Name";
            namelabel.Location      = new Point(0, 0);
            namelabel.Width         = 500;
            bulkDownlaodForm.Controls.Add(namelabel);
            _fileName               = new TextBox();
            _fileName.Location      = new Point(0, 30);
            bulkDownlaodForm.Controls.Add(_fileName);
            Button submit           = new Button();
            submit.Text             = "Submit";
            submit.Location         = new Point(0, 120);
            submit.Click            += BulkDownLdSubmit;
            bulkDownlaodForm.Controls.Add(submit);
            bulkDownlaodForm.Show();
        }

        // Broadcast an event to do the bulk download.
        public void BulkDownLdSubmit(object sender, EventArgs e)
        {
            BulkdDownldEvent?.Invoke(this, Convert.ToString(_fileName.Text));
        }

        // Display output of bulk download in main text box.
        public void DisplayDownload(string output)
        {
            outputHTML.Text = output;
        }

        // Broadcast an event to set the home page to the URL
        // currently in the search bar.
        private void makeHomePage_Click(object sender, EventArgs e)
        {
            if(searchBar.Text != "")
            {
                _home.URL = Convert.ToString(searchBar.Text);
                NewHomePageEvent?.Invoke(this, _home);
            }
            else
            {
                ShowMessage("Please enter a URL to set as new home page");
            }

        }

        // Allow a string string to be passed in as an argument
        // to be displayed in a message box.
        public void ShowMessage(string message)
        {
            MessageBox.Show(message);
        }

        // Broadcast an event to search for the current page again
        // and red-display the result.
        private void refresh_Click(object sender, EventArgs e)
        {
            if(searchBar.Text != "")
            {
                _link.Link = Convert.ToString(searchBar.Text);
                RequestURLEvent?.Invoke(this, _link, "new");
            }
        }

        public void IncrementPageIndex(int i)
        {
            _pageIndex += i;
        }

        public void DecrementPageIndex(int i)
        {
            _pageIndex -= i;
        }

        event IView.URLDelegate IView.RequestURLEvent
        {
            add
            {
                RequestURLEvent += value;
            }

            remove
            {
                RequestURLEvent = value;
            }
        }

        event IView.GetFavouritesDelegate IView.GetFavouritesEvent
        {
            add
            {
                GetFavouritesEvent += value;
            }

            remove
            {
                GetFavouritesEvent -= value;
            }
        }

        event IView.NewFavouriteDelegate IView.NewFavouriteEvent
        {
            add
            {
                NewFavouriteEvent += value;
            }

            remove
            {
                NewFavouriteEvent -= value;
            }
        }

        event IView.NewHomePageDelegate IView.NewHomePageEvent
        {
            add
            {
                NewHomePageEvent += value;
            }

            remove
            {
                NewHomePageEvent -= value;
            }
        }

        event IView.PageTraversalDelegate IView.PageTraversalEvent
        {
            add
            {
                PageTraversalEvent += value;
            }

            remove
            {
                PageTraversalEvent -= value;
            }
        }
    }
}
