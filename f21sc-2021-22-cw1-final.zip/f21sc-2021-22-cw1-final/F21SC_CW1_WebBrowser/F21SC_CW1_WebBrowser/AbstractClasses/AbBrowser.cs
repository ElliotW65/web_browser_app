﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using F21SC_CW1_WebBrowser.Interfaces;
using F21SC_CW1_WebBrowser.Collections;
using System.Collections;
using System.IO;
using System.Diagnostics;

namespace F21SC_CW1_WebBrowser.AbstractClasses
{
    public abstract class AbBrowser : IBrowser
    {
        /// <summary>
        /// The AbBrowser class provides an abstact class for the BrowserModel
        /// class and implements the IBrowser interface.
        /// </summary>

        // The AbBrowser class provides implementations for the IBrowser
        // interface. This class provides access to favourites and history
        // as well as hosting the HttpClient which is used for sending
        // HTTP requests and receiving HTTP responses.

        // Instantiate one instance of HTTPClient
        private static HttpClient client = new HttpClient();

        // Declare the events published by AbBrowser:
        public event IBrowser.PageChangeDelegate PageChanged;
        public event IBrowser.BulkDownloadDelegate BulkDownloadComplete;

        // Declare class variables:
        private PageChangeEventArgs                     _page;
        private BulkDownloadEventArgs<BulkDownldObj>    _bulkRequest;
        private Favourites                              _favourites;
        private History<DateTime, string>               _history;
        private List<String>                            _currentPage;
        private string                                  _path;

        // When an instance class that inherits from AbBrowser
        // is intantiated, a new favourites and history are created,
        // the path variable used for File IO is set and custom
        // EventArgs for page requests and bulk requests are instantiated.

        public AbBrowser(string path)
        {
            _favourites     = new Favourites();
            _history        = new History<DateTime, string>();
            _path           = path;
            _path           = "";
            _page           = new PageChangeEventArgs();
            _bulkRequest    = new BulkDownloadEventArgs<BulkDownldObj>();

            LoadFavourites();
            LoadHistory();
            
        }

        event IBrowser.PageChangeDelegate IBrowser.PageChanged
        {
            add
            {
                PageChanged += value;
            }

            remove
            {
                PageChanged -= value;
            }
        }

        event IBrowser.BulkDownloadDelegate IBrowser.BulkDownloadComplete
        {
            add
            {
                BulkDownloadComplete += value;
            }

            remove
            {
                BulkDownloadComplete -= value;
            }
        }

        public List<string> GetCurrentPage()
        {
            return _currentPage;
        }

        // Sets the current page but making a get request using
        // the URL passed as an argument. When request is complete
        // an event is broadcasted to notify observers an new page
        // has been loaded.
        public async void SetCurrentPage(string URL, string type)
        {
            if (!string.IsNullOrEmpty(URL))
            {
                try
                {
                    switch (type)
                    {
                        case "new":
                            _currentPage = await GetRequest(URL);
                            _history.Add(DateTime.Now, URL);
                            break;

                        case "history":
                            _currentPage = await GetRequest(URL);
                            break;
                    }
                }
                catch(HttpRequestException http)
                {
                    _page.RequestStatus = -1;
                    NotifyObservers();
                }
            }

            if (_currentPage != null)
            {
                _page.RequestStatus = 0;
                _page.URL = URL;
                _page.StatusCode = _currentPage[0];
                _page.Status = _currentPage[1];
                _page.Title = _currentPage[2];
                _page.HTML = _currentPage[3];
                NotifyObservers();
            }

        }

        // Broadcast an event to notify observers a new
        // page has been loaded.
        public void NotifyObservers()
        {
            PageChanged(this, _page);
        }

        // Send an HTTP request using the string URL passed in
        // as an argument. Returns a List<string> containing the
        // status code, status message, page title and HTML content.
        public async Task<List<string>> GetRequest(string URL)
        {
            if(URL == null)
            {
                Debug.WriteLine("Caught null url");
                throw new ArgumentException(URL);
            }
            List<string> arr            = new List<string>();

            HttpResponseMessage request = await client.GetAsync(URL);
            string content              = await request.Content.ReadAsStringAsync();

            int start                   = content.IndexOf("<title>") + 7;
            int stop                    = content.IndexOf("</title");
            int len                     = stop - start;
            string title                = content.Substring(start, len);
            string code                 = Convert.ToString((int)request.StatusCode);

            arr.Add(code);
            arr.Add(request.StatusCode.ToString());
            arr.Add(title.Trim());
            arr.Add(content);

            return arr;
        }

        // Send an HTTP request using the string URL passed in
        // as an argument. Returns a BulkDownldObj containing the
        // status code, content length in bytes and URL.
        public async Task<BulkDownldObj> GetBulkRequest(string URL)
        {
            try
            {
                List<string> arr = new List<string>();
                HttpResponseMessage request = await client.GetAsync(URL);

                arr.Add(Convert.ToString((int)request.StatusCode));

                arr.Add(Convert.ToString(request.Content.Headers.ContentLength));

                arr.Add(URL);

                long? bytes = request.Content.Headers.ContentLength;

                return new BulkDownldObj((int)request.StatusCode, bytes, URL);
            }

            catch
            {
                return null;
                // Handle errors
            }
            throw new NotImplementedException();
        }

        // Read in the favourites from a file and add them to
        // the favourites object instantiated with the constructor
        // was called.
        public void LoadFavourites()
        {
            string filename = "favourites.txt";
            string fullPath = Path.Combine(_path, filename);

            try
            {
                StreamReader str = new StreamReader(fullPath);

                string line;

                while ((line = str.ReadLine()) != null)
                {
                    string[] element = line.Split(" ");

                    if (element.Length == 2)
                    {
                        _favourites.Add(element[0], element[1]);
                    }

                }

                str.Close();
            }
            catch(FileNotFoundException f)
            {
                string newFileName = "favourites.txt";
                string newPath = Path.Combine(_path, newFileName);
                StreamWriter str = new StreamWriter(newPath);
                str.Close();
            }


        }

        // Write the favourites object in its current form to a file.
        public void SaveFavouritesToFile()
        {
            StreamWriter str = new StreamWriter("favourites.txt");
            foreach (KeyValuePair<string,string> pair in _favourites.GetFavourites())
            {
                str.WriteLine(string.Format("{0} {1}", pair.Key, pair.Value));
            }

            str.Close();

        }

        // Read in history from a file and add it to
        // the history object instantiated with the constructor
        // was called.
        public void LoadHistory()
        {
            string filename = "history.txt";
            string fullPath = Path.Combine(_path, filename);
            try
            {
                StreamReader str = new StreamReader(fullPath);

                string line;

                while ((line = str.ReadLine()) != null)
                {
                    
                    string[] element = line.Split(" ");
                    if (element.Length == 3)
                    {
                        DateTime key = DateTime.Parse(element[0] + " " + element[1]);
                        _history.Add(key, element[2]);
                    }

                }

                str.Close();
            }
            catch(FileNotFoundException f)
            {
                string newFileName = "history.txt";
                string newPath = Path.Combine(_path, newFileName);
                StreamWriter str = new StreamWriter(newPath);
                str.Close();
            }
            catch(DirectoryNotFoundException d)
            {
                // Handle
            }

        }

        // Write the history object in its current form to a file.
        public void SaveHistoryToFile()
        {
            string filename = "history.txt";
            string fullPath = Path.Combine(_path, filename);
            StreamWriter str = new StreamWriter("History.txt");
            foreach (KeyValuePair<DateTime, string> pair in _history.GetHistory())
            {
                str.WriteLine(string.Format("{0} {1}", pair.Key, pair.Value));
            }

            str.Close();

        }

        // Read in the home page from a file and set it as
        // the current page which will then load it into
        // the GUI. If the file is not found, create one
        // and set the home page to https://www.hw.ac.uk.
        public void LoadHomePage()
        {
            string filename = "homepage.txt";
            string fullPath = Path.Combine(_path, filename);
            try
            {
                StreamReader str = new StreamReader(fullPath);

                string line;

                if ((line = str.ReadLine()) != null)
                {
                    Debug.WriteLine(line);

                    SetCurrentPage(line, "new");

                }

                str.Close();

                
            }
            catch (FileNotFoundException f)
            {
                string newFileName = "homepage.txt";
                string newPath = Path.Combine(_path, newFileName);
                StreamWriter str = new StreamWriter(newPath);
                str.WriteLine("https://www.hw.ac.uk/");
                str.Close();
                LoadHomePage();
            }
            catch (DirectoryNotFoundException d)
            {
                // Handle
            }

        }

        // Write the history object in its current form to a file.
        public void SaveHomepageToFile(string url)
        {
            string path = @"C:\Users\Ellio\OneDrive\Documents\Masters\Y2\S1\F21SC_IP\Coursework\f21sc-2021-22-cw1\F21SC_CW1_WebBrowser\F21SC_CW1_WebBrowser\bin\Debug\netcoreapp3.1";
            string filename = "homepage.txt";
            string fullPath = Path.Combine(path, filename);
            StreamWriter str = new StreamWriter("HomePage.txt");
            str.WriteLine(url);

            str.Close();

        }

        // Read in the URLs to bulk download from a file,
        // search each one and add the result to the 
        // BulkRequestEventArgs object ready to be broadcast.
        public async void BulkDownload(string file)
        {
            try
            {
                string path = @"C:\Users\Ellio\OneDrive\Documents\Masters\Y2\S1\F21SC_IP\Coursework\f21sc-2021-22-cw1\F21SC_CW1_WebBrowser\F21SC_CW1_WebBrowser\bin\Debug\netcoreapp3.1";
                string filename = file;
                string fullPath = Path.Combine(path, filename);

                StreamReader str = new StreamReader(fullPath);

                string line;

                while ((line = str.ReadLine()) != null)
                {
                    _bulkRequest.Add(await GetBulkRequest(line));
                }

                str.Close();

                BulkDownloadComplete(this, _bulkRequest);
            }
            catch(FileNotFoundException fileNotFound)
            {
                Debug.WriteLine(fileNotFound.Message);
            }
            catch(UnauthorizedAccessException u)
            {
                Debug.WriteLine(u.Message);
            }

        }

        public void AddFavourite(string key, string value)
        {
            if(key != null && value != null)
            {
                _favourites.Add(key, value);
            }
        }

        public void AddHistory(DateTime time, string url)
        {
            _history.Add(time, url);
        }

        public ICollection<string> GetFavouriteNames()
        {
            return _favourites.GetKeys();
        }

        public History<DateTime, string> GetFullHistory()
        {
            return _history;
        }

        public string GetFavouriteURL(string key)
        {
            return _favourites.GetValue(key);
        }

        public string GetHistoryURL(int index)
        {
            return _history[index];
        }

        public void UpdateFavourite(string key, string value)
        {
            _favourites.UpdateValue(key, value);
        }

        public void UpdateFavouriteKey(string newKey, string oldKey)
        {
            _favourites.UpdateKey(newKey, oldKey);
        }

        public void DeleteFavourite(string key)
        {
            _favourites.RemoveValue(key);
        }

        public void DeleteHistoryItem(string i)
        {
            DateTime t = DateTime.Parse(i);
;           _history.Remove(t);
        }

        public void DeleteAllFavourites()
        {
            _favourites.ClearFavourites();
        }

        public void DeleteAllHistory()
        {
            _history.DeleteHistory();
        }

        public int GetHistoryLength()
        {
            return _history.GetLength();
        }
    }
}
