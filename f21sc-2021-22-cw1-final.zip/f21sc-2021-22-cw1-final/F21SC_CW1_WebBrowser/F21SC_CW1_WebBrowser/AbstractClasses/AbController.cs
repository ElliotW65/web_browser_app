﻿using F21SC_CW1_WebBrowser.Collections;
using F21SC_CW1_WebBrowser.Interfaces;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace F21SC_CW1_WebBrowser.AbstractClasses
{
    public abstract class AbController : IController
    {
        /// <summary>
        /// The AbBrowser class provides an abstact class for the BrowserController
        /// class and implements the IController interface.
        /// </summary>

        // The AbController class provides implementations for the IController
        // interface. This class does the majority of the event handling for
        // events published by the GUI in order to minimise the processing
        // carried out by the GUI.

        private IBrowser.PageChangeDelegate         pageDelegate;
        private IBrowser.BulkDownloadDelegate       bulkDownldDelegate;
        private IView.URLDelegate                   urlDelegate;
        private IView.GetFavouritesDelegate         guiLoadedDelegate;
        private IView.NewFavouriteDelegate          newFavouriteDelegate;
        private IView.NewHomePageDelegate           newHomePageDelegate;
        private IView.PageTraversalDelegate         pageTraversal;

        private IBrowser    _browser;
        private IView       _view;

        // When an instance class that inherits from AbController
        // is intantiated, it subscribes to the events published by
        // the GUI. To ensure loose coupling, the controller takes
        // in as arguments the IBrowser and IView interfaces which
        // it uses to carry out tasks rather than interact directly
        // with the instances of the model or view.

        public AbController(IBrowser browser, IView view)
        {
            this._browser = browser;
            pageDelegate = new IBrowser.PageChangeDelegate(this.UpdateView);
            _browser.PageChanged += pageDelegate;
            bulkDownldDelegate = new IBrowser.BulkDownloadDelegate(DownloadComplete);
            _browser.BulkDownloadComplete += bulkDownldDelegate;


            this._view              = view;
            urlDelegate             = new IView.URLDelegate(Search);
            _view.RequestURLEvent   += urlDelegate;
            guiLoadedDelegate       = new IView.GetFavouritesDelegate(UpdateFavourites);
            _view.GetFavouritesEvent += guiLoadedDelegate;
            newFavouriteDelegate    = new IView.NewFavouriteDelegate(AddNewFavourite);
            _view.NewFavouriteEvent += newFavouriteDelegate;
            newHomePageDelegate     = new IView.NewHomePageDelegate(SetNewHomePage);
            _view.NewHomePageEvent  += newHomePageDelegate;
            pageTraversal           = new IView.PageTraversalDelegate(HistoryTraversal);
            _view.PageTraversalEvent += pageTraversal;

            _view.RemoveFavouriteEvent      += RemoveFavourite;
            _view.GetFavURLEvent            += FavouriteRequest;
            _view.NewFaveNameEvent          += UpdateFavouriteName;
            _view.GetHistoryEvent           += GetHistory;
            _view.ViewCloseEvent            += SaveFavourites;
            _view.ViewCloseEvent            += SaveHistory;
            _view.ViewLoadedEvent           += InitialisePageIndex;
            _view.ViewLoadedEvent           += LoadHomePage;
            _view.BulkdDownldEvent          += BulkDownload;
            _view.DeleteAllHistoryEvent     += RemoveAllHistory;
            _view.DeleteHistoryItemEvent    += RemoveHistoryItem;
            _view.DeleteAllFavouritesEvent  += RemoveAllFavourites;

        }

        public void SetModel(AbBrowser browser)
        {
            this._browser = browser;
        }

        // Triggered when the GUI has loaded and calls the BrowserModel
        // to retrieve the home page.
        public void LoadHomePage(object sender, EventArgs e)
        {
            _browser.LoadHomePage();
        }

        // After a favourite is added, updated or removed, this method
        // updates the GUI's favourite list.
        public void UpdateFavourites(object sender, EventArgs e)
        {
            _view.UpdateFavouritesList(_browser.GetFavouriteNames());

        }

        // Initiates an HTTP request after receiving the even from the GUI.
        public void Search(object sender, RequestEventArgs e, string type)
        {
            if(e.Link.Substring(0,4) == "http")
            {
                try
                {
                    switch (type)
                    {
                        case "new":
                            _browser.SetCurrentPage(e.Link, "new");
                            break;

                        case "history":
                            _browser.SetCurrentPage(e.Link, "history");
                            break;
                    }
                }
                catch(ArgumentException a)
                {
                    _view.ShowMessage("Please enter a URL");
                }
                
            }
            else
            {
                _view.ShowMessage("Please enter a valid URL beginning with \"http(s)\".");
            }
            

            
        }

        // Updates the main text box of the GUI to display the
        // information returned by the HTTP request.
        public void UpdateView(object sender, PageChangeEventArgs e)
        {

            switch (e.RequestStatus)
            {
                case 0:
                    _view.UpdateSearchBar(e.URL);
                    _view.UpdateStatusCode(e.StatusCode + " - " + e.Status);
                    _view.UpdateTitle(e.Title);
                    _view.UpdateBrowserWindow(e.HTML);
                    _view.LoadHistory(_browser.GetFullHistory());
                    
                    break;
                case -1:
                    _view.ShowMessage("Could not connect to a server with this URL.");
                    break;

            }
        }

        // Gets the URL associated with a favourite item and searches
        // that URL in response to an event from the GUI.
        public void FavouriteRequest(object sender, string key)
        {
            RequestEventArgs link = new RequestEventArgs();
            link.Link = GetURL(key);
            Search(this, link, "new");
        }

        // Retrieve the current page according to the model.
        public List<string> GetResult()
        {
            return _browser.GetCurrentPage();
        }

        public List<string> LoadCurrentPage()
        {
            return _browser.GetCurrentPage();
        }

        public void AddNewFavourite(object sender, NewFavouriteEventArgs e)
        {
            try
            {
                _browser.AddFavourite(e.NewName, e.NewLink);
            }
            catch(ArgumentException a)
            {
                _view.ShowMessage("Favourite name already exists. Please choose a different name");
            }
        }

        public void AddHistory(DateTime time, string value)
        {
            _browser.AddHistory(time, value);
        }

        // Returns the keys of the favourites collection.
        public ICollection<string> GetFavNames()
        {
            return _browser.GetFavouriteNames();
        }

        // Returns the URL associated with a favourite key.
        public string GetURL(string URL)
        {
            return _browser.GetFavouriteURL(URL);
        }

        // Returns the URL associated with the history
        // item at a given index.
        public string GetHistoryURL(int index)
        {
            return _browser.GetHistoryURL(index);
        }

        // Returns the full History object currently held
        // by the BrowserModel.
        public void GetHistory(object sender, EventArgs e)
        {
            _view.LoadHistory(_browser.GetFullHistory());
        }

        public void EditFavourite(string key, string value)
        {
            _browser.UpdateFavourite(key, value);
        }

        public void UpdateFavouriteName(object sender, NewFavouriteEventArgs e)
        {
            _browser.UpdateFavouriteKey(e.NewName, e.OldName);
            _view.UpdateFavouritesList(GetFavNames());
        }

        public void RemoveFavourite(object sender, string key)
        {
            _browser.DeleteFavourite(key);
            _view.UpdateFavouritesList(GetFavNames());
        }

        public void RemoveAllFavourites(object sender, EventArgs e)
        {
            _browser.DeleteAllFavourites();
            _view.UpdateFavouritesList(GetFavNames());
        }

        public void RemoveHistoryItem(object sender, string e)
        {
            _browser.DeleteHistoryItem(e);
        }

        public void RemoveAllHistory(object sender, EventArgs e)
        {
            _browser.DeleteAllHistory();
            _view.LoadHistory(_browser.GetFullHistory());
        }

        public void SaveFavourites(object sender, EventArgs e)
        {
            _browser.SaveFavouritesToFile();
        }

        public void SaveHistory(object sender, EventArgs e)
        {
            _browser.SaveHistoryToFile();
        }

        // Initiates the index of the page when the GUI loads.
        // Used to traverse the history that is loaded in from
        // a file.
        public void InitialisePageIndex(object sender, EventArgs e)
        {
            _view.InitPageIndex(_browser.GetHistoryLength());
        }

        // Triggered when either the forward or back navigation buttons
        // on the browser are clicked.
        // The pageIndex is used to retrieve the correct history URL based
        // on its index, and depending on whether it was a back or forward
        // instruction, the pageIndex gets incremented or decremented.
        public void HistoryTraversal(object sender, int e, string dir)
        {
            try
            {
                RequestEventArgs link = new RequestEventArgs();

                History<DateTime, string> history = _browser.GetFullHistory();

                switch (dir)
                {
                    case "forward":
                        if (e == history.GetLength() - 1)
                        {
                            // Do nothing
                        }
                        else if (e < history.GetLength() - 1)
                        {
                            e += 1;
                            _view.IncrementPageIndex(1);
                            link.Link = history[e];

                            Search(this, link, "history");
                        }
                        break;

                    case "back":
                        if (e == 0)
                        {
                            // Do nothing
                        }
                        else if(e > 0)
                        {
                            e -= 1;
                            _view.DecrementPageIndex(1);
                            link.Link = history[e];
                            Search(this, link, "history");
                        }
                        break;
                }

            }
            catch(ArgumentOutOfRangeException a)
            {
                // No event needed, nothing will be returned when a page
                // that is out of range is requested.
            }


        }

        // Triggers the bulk download when requested by the user
        // from the GUI.
        public void BulkDownload(object sender, string url)
        {
            try
            {
                _browser.BulkDownload(url);
            }
            catch(FileNotFoundException filNotFound)
            {
                _view.ShowMessage("Could not find file.");
            }
            

        }

        // Is notified by the BrowserModel when the bulk download is
        // complete and can now retrieve the result from the shared
        // object BulkDownloadEventArgs.
        // The result is then written to the main text box of the GUI.
        public void DownloadComplete(object sender, BulkDownloadEventArgs<BulkDownldObj> dwnld)
        {
            string output = "";

            foreach(BulkDownldObj obj in dwnld)
            {
                output += obj.Serialise();
                output += "\r\n";
            }

            _view.DisplayDownload(output);
        }

        public void SetNewHomePage(object sender, HomePageEventArgs e)
        {
            _browser.SaveHomepageToFile(e.URL);
        }

    }
}
