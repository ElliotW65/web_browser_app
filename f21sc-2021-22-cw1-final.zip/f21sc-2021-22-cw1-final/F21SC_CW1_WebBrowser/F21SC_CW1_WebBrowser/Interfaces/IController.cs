﻿using F21SC_CW1_WebBrowser.AbstractClasses;
using F21SC_CW1_WebBrowser.Collections;
using System;
using System.Collections.Generic;
using System.Text;

namespace F21SC_CW1_WebBrowser.Interfaces
{
    interface IController
    {

        public void SetModel(AbBrowser browser);

        public void LoadHomePage(object sender, EventArgs e);

        public void UpdateFavourites(object sender, EventArgs e);

        public void Search(object sender, RequestEventArgs e, string type);

        public void UpdateView(object sender, PageChangeEventArgs e);

        public void FavouriteRequest(object sender, string key);

        public List<string> GetResult();

        public List<string> LoadCurrentPage();

        public void AddNewFavourite(object sender, NewFavouriteEventArgs e);

        public void AddHistory(DateTime time, string value);

        public ICollection<string> GetFavNames();

        public string GetURL(string URL);

        public string GetHistoryURL(int index);

        public void GetHistory(object sender, EventArgs e);

        public void EditFavourite(string key, string value);

        public void UpdateFavouriteName(object sender, NewFavouriteEventArgs e);

        public void RemoveFavourite(object sender, string key);

        public void RemoveAllFavourites(object sender, EventArgs e);

        public void RemoveHistoryItem(object sender, string e);

        public void RemoveAllHistory(object sender, EventArgs e);

        public void SaveFavourites(object sender, EventArgs e);

        public void SaveHistory(object sender, EventArgs e);

        public void InitialisePageIndex(object sender, EventArgs e);

        public void HistoryTraversal(object sender, int e, string dir);

        public void BulkDownload(object sender, string url);

        public void DownloadComplete(object sender, BulkDownloadEventArgs<BulkDownldObj> dwnld);

        public void SetNewHomePage(object sender, HomePageEventArgs e);

    }
}
