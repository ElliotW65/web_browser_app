﻿using F21SC_CW1_WebBrowser.Collections;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace F21SC_CW1_WebBrowser.Interfaces
{
    public interface IView
    {
        public delegate void URLDelegate(object sender, RequestEventArgs e, string type);

        public delegate void GetFavouritesDelegate(object sender, EventArgs e);

        public delegate void NewFavouriteDelegate(object sender, NewFavouriteEventArgs e);

        public delegate void NewHomePageDelegate(object sender, HomePageEventArgs e);

        public delegate void PageTraversalDelegate(object sender, int e, string dir);

        public event URLDelegate RequestURLEvent;

        public event GetFavouritesDelegate GetFavouritesEvent;

        public event NewFavouriteDelegate NewFavouriteEvent;

        public event NewHomePageDelegate NewHomePageEvent;

        public event PageTraversalDelegate PageTraversalEvent;

        public event EventHandler<NewFavouriteEventArgs> NewFaveNameEvent;

        public event EventHandler<string> RemoveFavouriteEvent;

        public event EventHandler<string> GetFavURLEvent;

        public event EventHandler<string> BulkdDownldEvent;

        public event EventHandler GetHistoryEvent;

        public event EventHandler DeleteAllHistoryEvent;

        public event EventHandler DeleteAllFavouritesEvent;

        public event EventHandler<string> DeleteHistoryItemEvent;

        public event EventHandler ViewCloseEvent;

        public event EventHandler ViewLoadedEvent;

        void UpdateFavouritesList(ICollection<string> keys);

        void DeleteAllFavourites(object sender, EventArgs e);

        void NewFavourite(object sender, EventArgs e);

        void AddFavourite(object sender, EventArgs e);

        void NewFavouriteName(object sender, EventArgs e);

        void UpdateFavouriteName(object sender, EventArgs e);

        void RemoveFavourite(object sender, EventArgs e);

        void AddNewFavourite(object sender, EventArgs e);

        void LoadHistory(History<DateTime, string> history);

        void DeleteHistoryItem(object sender, EventArgs e);

        void InitPageIndex(int historyLength);

        void UpdateSearchBar(string url);

        void UpdateTitle(string title);

        void UpdateBrowserWindow(string html);

        void UpdateStatusCode(string code);

        void BulkDownLdSubmit(object sender, EventArgs e);

        void DisplayDownload(string output);

        void ShowMessage(string message);

        void IncrementPageIndex(int i);

        void DecrementPageIndex(int i);
    }
}

