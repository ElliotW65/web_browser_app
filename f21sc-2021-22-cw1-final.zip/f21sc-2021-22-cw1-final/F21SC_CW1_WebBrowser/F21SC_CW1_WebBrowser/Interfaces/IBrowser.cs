﻿using F21SC_CW1_WebBrowser.Collections;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace F21SC_CW1_WebBrowser.Interfaces
{
    public interface IBrowser
    {
        public delegate void PageChangeDelegate(object sender, PageChangeEventArgs e);
        public delegate void BulkDownloadDelegate(object sender, BulkDownloadEventArgs<BulkDownldObj> e);

        public event PageChangeDelegate PageChanged;
        public event BulkDownloadDelegate BulkDownloadComplete;

        public List<string> GetCurrentPage();


        public void SetCurrentPage(string URL, string type);


        public void NotifyObservers();


        public Task<List<string>> GetRequest(string URL);


        public Task<BulkDownldObj> GetBulkRequest(string URL);


        public void LoadFavourites();


        public void SaveFavouritesToFile();


        public void LoadHistory();


        public void SaveHistoryToFile();


        public void LoadHomePage();


        public void SaveHomepageToFile(string url);



        public void BulkDownload(string file);


        public void AddFavourite(string key, string value);


        public void AddHistory(DateTime time, string url);


        public ICollection<string> GetFavouriteNames();


        public History<DateTime, string> GetFullHistory();


        public string GetFavouriteURL(string key);


        public string GetHistoryURL(int index);


        public void UpdateFavourite(string key, string value);


        public void UpdateFavouriteKey(string newKey, string oldKey);


        public void DeleteFavourite(string key);


        public void DeleteHistoryItem(string i);


        public void DeleteAllFavourites();


        public void DeleteAllHistory();


        public int GetHistoryLength();

    }
}
