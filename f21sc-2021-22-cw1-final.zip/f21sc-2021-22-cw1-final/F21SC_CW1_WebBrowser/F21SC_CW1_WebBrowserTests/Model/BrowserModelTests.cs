﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using F21SC_CW1_WebBrowser.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace F21SC_CW1_WebBrowser.Model.Tests
{
    [TestClass()]
    public class BrowserModelTests
    {
        //[TestMethod()]
        //public void BrowserModelTest()
        //{
        //    Assert.Fail();
        //}

        [TestMethod()]
        [ExpectedException(typeof(ArgumentException))]
        public void SetCurrentPage_ResultLength()
        {
            // Arrange

            string path = @"C:\Users\Ellio\OneDrive\Documents\Masters\Y2\S1\F21SC_IP\Coursework\f21sc-2021-22-cw1\F21SC_CW1_WebBrowser\F21SC_CW1_WebBrowser\bin\Debug\netcoreapp3.1";
            BrowserModel model = new BrowserModel(path);
            string url = "";
            string type = "new";

            //model.SetCurrentPage(url, type);
            model.SetCurrentPage(null, type);
            // Act and assert

        }

        [TestMethod()]
        [ExpectedException(typeof(ArgumentException))]
        public void GetNum_Test()
        {
            string path = @"C:\Users\Ellio\OneDrive\Documents\Masters\Y2\S1\F21SC_IP\Coursework\f21sc-2021-22-cw1\F21SC_CW1_WebBrowser\F21SC_CW1_WebBrowser\bin\Debug\netcoreapp3.1";
            BrowserModel model = new BrowserModel(path);
            model.GetNum();
            //Assert.ThrowsException<ArgumentException>(() => model.GetNum());
            //Assert.AreEqual(1, model.GetNum());
        }
    }
}