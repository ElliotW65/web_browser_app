﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using F21SC_CW1_WebBrowser.Controller;
using System;
using System.Collections.Generic;
using System.Text;
using F21SC_CW1_WebBrowser.Model;
using F21SC_CW1_WebBrowser.Collections;

namespace F21SC_CW1_WebBrowser.Controller.Tests
{
    [TestClass()]
    public class BrowserControllerTests
    {
        [TestMethod()]
        public void BrowserControllerTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        [ExpectedException(typeof(ArgumentException))]
        public void AddNewFavourite_DuplicateKey()
        {
            string path = @"C:\Users\Ellio\OneDrive\Documents\Masters\Y2\S1\F21SC_IP\Coursework\f21sc-2021-22-cw1\F21SC_CW1_WebBrowser\F21SC_CW1_WebBrowser\bin\Debug\netcoreapp3.1";
            BrowserModel model = new BrowserModel(path);
            View view = new View();

            model.AddFavourite("testFav", "testLink");

            BrowserController controller = new BrowserController(model, view);

            NewFavouriteEventArgs newFavourite = new NewFavouriteEventArgs();

            newFavourite.NewLink = "";
            newFavourite.OldName = "testFave";
            newFavourite.NewName = "testFave";

            controller.AddNewFavourite(this, newFavourite);
        }
    }
}