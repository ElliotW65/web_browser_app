# f21sc-2021-22-CW1

A blank project, just with README and CW spec, for CW1 implementation and to ask questions about the coding in C#

Find the 2 versions of the coursework spec in this repo:
- (Coursework_browser_10.pdf)[CW1 spec for F20SC (UG)]
- (Coursework_browser_11.pdf)[CW1 spec for F21SC (PG)]

Fork and clone this project, so that you can ask questions about the code through gitlab-student,
and to use version control on your code.

Usage of gitlab-student is not mandatory, but recommended.

